# Calculator Android Project

This package wraps the existing Calculator HTML/React app in a native Android WebView.

## App
- Name: Calculator
- Package: `com.calculator.app`
- Min SDK: 24 (Android 7.0)
- Target SDK: 35
- Orientation: Portrait

## Features preserved
Calculator/vault UI, local storage, Firebase/Firestore online chat code, contacts, photos/videos, notes and existing web assets are preserved from the supplied source. No Firebase configuration was changed.

## Native Android additions
- `INTERNET` permission
- Runtime `READ_CONTACTS` permission
- Native contact picker bridge: `window.AndroidPicker.pickContact(callbackName)`
- Result callback: `window.__nativeContactResult(name, phone)`
- Android Photo Picker on Android 13+ when available, with document-picker fallback for image/video and multi-select
- WebView JavaScript, DOM storage, database, local/file/content access
- Back button and WebView state restoration

## Build
Open the `android/` directory as the Android Studio project. Sync Gradle, then run `assembleDebug`.

Expected debug output: `android/app/build/outputs/apk/debug/app-debug.apk`.

This source package does not include a generated APK unless an Android SDK/Gradle build is actually run successfully.

## Release signing
Create a keystore with Android Studio or `keytool`, then configure a `signingConfigs { release { ... } }` block in `android/app/build.gradle`. Never commit a keystore or passwords. Build an AAB for Google Play with `./gradlew bundleRelease`.

## Firebase/security
The supplied Firebase web configuration is retained. Before production release, configure strict Firestore Security Rules, authentication requirements, and appropriate API-key/application restrictions in Firebase/Google Cloud.

## Ads/privacy
Existing web ad code/assets, if present in the supplied source, were not intentionally removed. Review third-party ad SDK/script privacy disclosures and consent requirements before production release.
