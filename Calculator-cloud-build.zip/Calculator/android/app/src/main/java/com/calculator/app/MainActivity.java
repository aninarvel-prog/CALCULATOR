package com.calculator.app;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int CONTACT_PERMISSION = 1001;
    private static final int CONTACT_PICK = 1002;
    private static final int MEDIA_PICK = 1003;
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new NativeBridge(), "AndroidPicker");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb; openMediaPicker(); return true;
            }
        });
        setContentView(webView);
        if (state != null) webView.restoreState(state); else webView.loadUrl("file:///android_asset/index.html");
    }

    private void openMediaPicker() {
        Intent intent;
        if (Build.VERSION.SDK_INT >= 33) {
            intent = new Intent(MediaStore.ACTION_PICK_IMAGES);
            intent.setType("image/*");
            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            intent.putExtra("android.provider.extra.PICK_IMAGES_MAX", 50);
            // Some Android versions ignore multi-select here; WebView still receives a valid single result.
            try { startActivityForResult(intent, MEDIA_PICK); return; } catch (Exception ignored) { }
        }
        intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "video/*"});
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(intent, MEDIA_PICK);
    }

    private void startContactPicker(String callback) {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, CONTACT_PERMISSION); return;
        }
        Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
        startActivityForResult(intent, CONTACT_PICK);
    }

    private void sendContact(String name, String phone) {
        String js = "window.__nativeContactResult && window.__nativeContactResult(" + quote(name) + "," + quote(phone) + ");";
        webView.post(() -> webView.evaluateJavascript(js, null));
    }
    private String quote(String s) { if (s == null) s=""; return "'" + s.replace("\\","\\\\").replace("'","\\'").replace("\n","\\n").replace("\r","\\r") + "'"; }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CONTACT_PICK) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri uri=data.getData(); ContentResolver cr=getContentResolver();
                try (Cursor c=cr.query(uri,new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER},null,null,null)) {
                    if(c!=null && c.moveToFirst()) sendContact(c.getString(0),c.getString(1)); else sendContact("","");
                }
            } else sendContact("","");
            return;
        }
        if (requestCode == MEDIA_PICK && fileCallback != null) {
            Uri[] results=null;
            if(resultCode==RESULT_OK && data!=null) {
                if(data.getClipData()!=null){ int n=data.getClipData().getItemCount(); results=new Uri[n]; for(int i=0;i<n;i++) results[i]=data.getClipData().getItemAt(i).getUri(); }
                else if(data.getData()!=null) results=new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(results); fileCallback=null;
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==CONTACT_PERMISSION){ if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED) startContactPicker("__nativeContactResult"); else sendContact("",""); }
    }
    @Override public void onBackPressed(){ if(webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
    @Override protected void onSaveInstanceState(Bundle out){ webView.saveState(out); super.onSaveInstanceState(out); }
    public class NativeBridge { @JavascriptInterface public void pickContact(String callbackName){ runOnUiThread(() -> startContactPicker(callbackName)); } }
}
